
(function(){
    'use strict';

    var ctx = document.getElementById("J-Canvas").getContext("2d");
    var data = {
        labels: ["4.27", "5.4", "5.11", "5.18", "5.25", "6.1", "6.8"],
        datasets: [
            {
                label: "恭喜发车均价",
                fillColor: "rgba(237,28,12,0)",
                strokeColor: "rgba(237,28,12,1)",
                pointColor: "rgba(237,28,12,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: [24.62, 25.22, 26.45, 26.22, 27, 27.22, 25.3]
            },
            {
                label: "恭喜发车低价",
                fillColor: "rgba(85,191,52,0)",
                strokeColor: "rgba(85,191,52,1)",
                pointColor: "rgba(85,191,52,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(151,187,205,1)",
                data: [24.22, 25.33, 26, 27.2, 24.55, 25.11, 24]
            },
            {
                label: "市场平均报价",
                fillColor: "rgba(233,203,35,0)",
                strokeColor: "rgba(233,203,35,1)",
                pointColor: "rgba(233,203,35,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(151,187,205,1)",
                data: [24.32, 25.23, 26.4, 27.1, 24.4, 25.11, 23.5]
            }
        ]
    };

    // Object.defineProperty(Object.prototype, '_this', {
    //     get: function(){ return JSON.stringify(this); }
    // });
    //
    // var B = function(){};
    // B.prototype = {
    //     name : 'hello'
    // };
    // console.debug(B.prototype, (new B())._this);

    var myLineChart = new Chart(ctx).Line(data, {
        animationEasing : 'easeOutQuint',
        multiTooltipTemplate: "<%= datasetLabel %> : <%= value %>",
    });

    $('.swiper-container').css({height: $(window).width()/2});
    var mySwiper = new Swiper ('.swiper-container', {
        loop: true,
        pagination: '.swiper-pagination',
        autoplay: 3000,
    });
}());
