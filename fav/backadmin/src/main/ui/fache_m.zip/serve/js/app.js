window.Fache = {UI:{}};

(function(namespace){
    'use strict';

    var body = $('body');

    /*===================
     选择组件
    ===================*/
    var selectorDefault = {
        title : '请选择'
    };
    var Selector = function(dom, option){
        this.dom = dom;
        this.option = $.extend({}, selectorDefault, option);
        if (dom.data('single') == 1) {
            this.single = true;
        } else {
            this.single = false;
        }
        this.getCurrent();
        this.getOptions();
        this.render();
        this.eventBind();
    };

    Selector.prototype = {
        getOptions : function(){
            var options = {};
            var _this = this;
            _this.dom.find('.item').each(function(){
                var _ = $(this);
                options[_.data('key')] = {
                    key : _.data('key'),
                    value : _.data('value'),
                    checked : _this.value.indexOf(_.data('key') + "") > -1
                };
            });
            _this.options = options;
        },
        getCurrent : function(){
            this.value = this.dom.find('input').val().split(',');
        },
        render : function() {
            var tmpl = '<div id="J-CommSelectorOverlay" class="comm-selector-overlay">';
                tmpl += '  <div class="inner">';
                tmpl += '    <div class="header">'+ this.option.title +'</div>';
                for (var k in this.options) {
                    var item = this.options[k];
                    if (item.checked) {
                        tmpl += '<div class="item active" id="J-CSOItem'+item.key+'" data-key="'+item.key+'">'+ item.value +'</div>';
                    } else {
                        tmpl += '<div class="item" id="J-CSOItem'+item.key+'" data-key="'+item.key+'">'+ item.value +'</div>';
                    }
                }
                tmpl += '  </div>';
                tmpl += '</div>';

            $('body').append(tmpl);
        },
        eventBind : function() {
            var wrap = $('#J-CommSelectorOverlay');
            var _this = this;
            wrap.on('tap', function(e){
                var tar = $(e.target);
                if (tar.hasClass('comm-selector-overlay')) {
                    _this.update();
                    wrap.remove();
                } else if (tar.hasClass('item')) {
                    var key = tar.data('key');
                    if (tar.hasClass('active') && !_this.single) {
                        _this.options[key].checked = false;
                    } else if (!tar.hasClass('active')) {
                        _this.options[key].checked = true;
                        if (_this.single) {
                            tar.siblings('.item').each(function(){
                                var _key = $(this).data('key');
                                _this.options[_key].checked = false;
                            });
                        }
                    }
                }
                _this.update();
                e.preventDefault();
                e.stopPropagation();
            });
        },
        update : function(){
            var value = [];
            var text = [];
            for (var key in this.options) {
                var item = this.options[key];
                if (item.checked) {
                    $('#J-CSOItem'+item.key).addClass('active');
                    value.push(item.key);
                    text.push(item.value);
                } else {
                    $('#J-CSOItem'+item.key).removeClass('active');
                }
            }
            this.value = value;
            this.dom.find('input').val(this.value.join(','));
            if (value.length) {
                this.dom.find('.value').html(text.join(','));
            } else {
                this.dom.find('.value').html('选择');
            }
        }
    };

    namespace.selector = function(){
        $('.comm-selector').each(function(){
            var _this = $(this);
            var title = _this.parents('.form-group').find('.label').html();
            _this.on('tap', function(){
                new Selector(_this, {title: title});
            });
        });
    };

    /*====================
    checkbox
    =====================*/
    var checkCheckbox = function(){
        var _this = $(this);
        var checkbox = _this.find('input');
        if (checkbox.is(':checked')) {
            _this.addClass('active');
        } else {
            _this.removeClass('active');
        }
    };

    namespace.checkbox = function(){
        $('.checkbox').each(checkCheckbox);
        $('.checkbox').on('click', checkCheckbox);
    };

    /*===============
      弹出提示层

      option:
        id(String) - dom id
        type(String) - 类型: waring, right
        body(String) - 显示内容
        btnText(String) - 按钮文案
        close(function) - 关闭回调
    ===============*/
    namespace.Modal = function(option){
        this.option = option;
        if (this.option.id) {
            this.modal = $('#' + option.id);
            this.bind();
        } else {
            this.init();
        }
    };
    namespace.Modal.prototype = {
        init : function(){
            var tmpl = '<div id="_Modal" class="comm-modal">';
                tmpl += '<div class="modal">';
                tmpl += '    <div class="close j-close">&times;</div>';
                if (this.option.type === 'warn') {
                    tmpl += '    <div class="type"><i class="comm-img gray-warn"></i></div>';
                } else if (this.option.type === 'right') {
                    tmpl += '    <div class="type"><i class="comm-img gray-tick"></i></div>';
                }
                tmpl += '    <div class="text">'+ this.option.body +'</div>';
                tmpl += '    <div class="action">';
                tmpl += '        <div class="button button-primary j-close">'+ this.option.btnText +'</div>';
                tmpl += '    </div>';
                tmpl += '    </div>';
                tmpl += '</div>';
            bod.append(tmpl);
            this.modal = $('#_Modal');
            this.bind();
        },
        bind : function(){
            var _this = this;
            this.modal.find('.j-close').click(function(){
                _this.option.close && _this.option.close.call(_this);
                if (_this.option.id) {
                    _this.modal.hide();
                } else {
                    _this.modal.remove();
                }
            });
        },
        show : function() {
            this.modal.show();
        }
    };

    /*====================
    alert
    =====================*/
    namespace.alert = function(msg){alert(msg);};

    /*====================
     comm-search-form
    =====================*/
    var searchForm = $('.comm-search-form');
    $('.comm-search-form').find('input').on('focus', function(){
        searchForm.find('.placeholder').hide();
    }).on('blur', function(){
        if (!$(this).val())
            searchForm.find('.placeholder').show();
    });

    /*====================
     FilterPanel
    =====================*/
    var Fp = function(){
        this.dom = $('#J-FPanel');
        this.eventBind();
    };
    var fp;
    Fp.prototype = {
        show: function(){
            var _this = this;
            _this.dom.css('display', 'block');
            setTimeout(function(){
                _this.dom.addClass('active');
                _this.dom.find('.inner').addClass('active');
            }, 16);
        },
        eventBind: function(){
            var _this = this;
            var header = this.dom.find('.j-header0');
            var selectors = this.dom.find('.comm-selector');
            header.children('.left').on('tap', function(){_this.hide();});
            header.children('.right').on('tap', function(){_this.hide();});
            selectors.on('tap', function(){
                var items = {};
                var _ = $(this);
                var title = _.parents('.form-group').find('.label').html();
                var keyVal = _.find('input').val();
                _.find('.item').each(function(){
                    var _item = $(this);
                    var key = _item.data('key');
                    var val = _item.data('value');
                    items[key] = {
                        value : val,
                        checked : key == keyVal
                    };
                });
                _this.showSubPanel({
                    selector : _,
                    title : title,
                    key : keyVal,
                    items : items,
                    ok : function(key) {
                        console.debug(key);
                        _.find('input').val(key);
                        _.find('.value').html(items[key].value);
                    }
                });
            });
        },
        hide: function(){
            var _this = this;
            _this.dom.removeClass('active');
            _this.dom.find('.inner').removeClass('active');
            setTimeout(function(){
                _this.dom.css('display', 'none');
            }, 400);
        },
        showSubPanel: function(option){
            var _this = this;
            var tmpl = '';
            var checkedKey;
            tmpl += '<div id="J-SubPanel" class="inner">';
            tmpl += '   <div class="header"><div class="left">取消</div><div class="right">确定</div><div class="title">'+option.title+'</div></div>';
            tmpl += '     <div class="comm-form">';
            for(var key in option.items) {
                var item = option.items[key];
                if (item.checked) {
                    checkedKey = key;
                    tmpl += '<div class="form-group mod-buy-tick" data-key="'+key+'"><span class="label">'+ option.items[key].value +'</span><div class="input">&nbsp;</div></div>';
                } else {
                    tmpl += '<div class="form-group" data-key="'+key+'"><span class="label">'+ option.items[key].value +'</span><div class="input">&nbsp;</div></div>';
                }
            }
            tmpl += '    </div>';
            tmpl += '</div>';

            this.dom.append(tmpl);

            var subPanel = $('#J-SubPanel');
            subPanel.css('display', 'block');
            setTimeout(function(){
                subPanel.addClass('active');
            }, 16);

            function hideSubPanel(){
                subPanel.removeClass('active');
                setTimeout(function(){
                    subPanel.remove();
                }, 400);
            }

            subPanel.find('.left').on('tap', hideSubPanel);
            subPanel.find('.right').on('tap', function(){
                option.ok(checkedKey);
                hideSubPanel();
            });

            subPanel.find('.form-group').on('tap', function(){
                var _ = $(this);
                _.addClass('mod-buy-tick')
                 .siblings().removeClass('mod-buy-tick');
                for (var key in option.items) {
                    if (key == _.data('key')) {
                        checkedKey = key;
                        option.items[key].checked = true;
                    } else {
                        option.items[key].checked = false;
                    }
                }
            });
        }
    };
    namespace.FilterPanel = {
        show : function(){
            if (!fp) fp = new Fp();
            fp.show();
        }
    };

}(Fache.UI));
